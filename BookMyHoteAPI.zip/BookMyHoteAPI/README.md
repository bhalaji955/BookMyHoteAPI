# BookMyHoteAPI
This Api is used to Fetch hotels, Book hotel , Add hotel. Written in Raml in AnypointStudio.
